<?php
    require 'db.php';

    $sql = 'SELECT * FROM automobili';
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
        // Creazione dell'oggetto SimpleXMLElement
        $xml = new SimpleXMLElement('<root/>');
    
        while ($row = $result->fetch_assoc()) 
        {
            $record = $xml->addChild('record');
            foreach ($row as $key => $value) 
            {
                $record->addChild($key, htmlspecialchars($value));
            }
        }
    
        // Nome del file XML
        $fileName = "../data/automobili.xml";
    
        // Salvataggio nel file XML
        $xml->asXML($fileName);
    
    } 
    $conn->close();
?>